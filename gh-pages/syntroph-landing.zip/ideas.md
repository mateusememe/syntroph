# Syntroph — Direção visual

## Abordagens consideradas

### Theme Name: Bio-futurist circuit
Very Brief Intro: Uma interface escura e viva, inspirada em organismos bioluminescentes e circuitos observados sob luz negra. O foco é transformar arquitetura de software em matéria visual.
Probability: 0.07

### Theme Name: Terminal observatory
Very Brief Intro: Uma linguagem de laboratório técnico, com painéis de telemetria, tipografia monoespacial e composição editorial assimétrica. Mais documental do que exuberante.
Probability: 0.04

### Theme Name: Mineral symbiosis
Very Brief Intro: Uma leitura mais silenciosa e mineral da marca, combinando preto profundo, linhas finas e acentos de cor como veios luminosos em uma pedra.
Probability: 0.02

## Abordagem escolhida: Bio-futurist circuit

### Design Movement
Bio-futurismo técnico com referências de cyberpunk contido, diagramas científicos e sistemas de circuitos orgânicos.

### Core Principles
1. Toda superfície deve parecer um canvas quase negro, com textura sutil de scanline/filme.
2. A composição deve alternar precisão estrutural e sinais orgânicos: linhas finas, nós, fluxos e um núcleo luminoso.
3. O contraste vem de ciano bioluminescente, violeta e azul-core, sem recorrer a superfícies brancas ou gradientes genéricos.
4. A interface deve comunicar engenharia com poesia controlada: declarativa, técnica e ligeiramente metafórica.

### Color Philosophy
O preto-void cria um campo de observação; o ciano representa o organismo emissor e a circulação de energia; o violeta representa o organismo receptor; o azul-core marca o ponto de troca. A cor é semântica e funcional, não decorativa.

### Layout Paradigm
Uma composição editorial assimétrica com uma coluna lateral de metadados e uma coluna principal de narrativa. Diagramas atravessam a largura como estruturas de conexão. Seções usam respiros largos, linhas-divisoras e cartões compactos em vez de uma sequência centralizada de blocos iguais.

### Signature Elements
- Linhas de circuito orgânico com pontos de passagem e partículas lentas.
- Orbe central azul como metáfora visual da troca metabólica.
- Divisores finos em gradiente ciano-violeta e textura de scanline.

### Interaction Philosophy
Interações devem parecer energia respondendo ao contato: foco e hover revelam brilho e linhas auxiliares, sem mudanças abruptas de cor. O sistema confirma cliques com escala discreta e realce luminoso.

### Animation
A animação será lenta e respiratória em elementos ambientais, com ciclos de 6–10 segundos. Partículas percorrerão caminhos SVG e nós pulsarão suavemente. Transições de UI ficam abaixo de 300ms. `prefers-reduced-motion` desliga partículas e pulsos, preservando estados estáticos e legíveis.

### Typography System
Display: Space Grotesk, pesos 500–700, tracking apertado para títulos. Body: IBM Plex Sans, 400–500, line-height generoso. Code: JetBrains Mono, usado em comandos, nomes de portas e metadados.

### Brand Essence
Um orquestrador open-source para equipes que querem agentes de código que aprendam uns com os outros — em vez de reiniciar cada sessão do zero. Personalidade: simbiótica, rigorosa, viva.

### Brand Voice
Headlines são curtas e declarativas. CTAs são verbos concretos. Microcopy usa termos de engenharia sem jargão promocional.

Exemplo 1: “Give every session something to inherit.”
Exemplo 2: “Compose the next agent from what the last one learned.”

### Wordmark & Logo
O símbolo enviado é a marca principal: dois organismos lineares entrelaçados ao redor de um núcleo luminoso. O wordmark será tipográfico, em Space Grotesk, com espaçamento amplo e um detalhe de cor no ponto de troca — nunca o nome em uma fonte padrão isolada.

### Signature Brand Color
`#4DFFE0` — Syntroph cyan, o ciano proprietário que identifica fluxo, memória e o organismo emissor.

## Regras de implementação

- Usar a imagem enviada como logo no header, hero e footer, com alt text descritivo.
- Implementar seletor de idioma para inglês, espanhol e português do Brasil.
- Implementar alternância entre dark e light mode, mantendo a linguagem de alto contraste e ajustando os tokens sem perder a identidade.
- Todos os CTAs primários apontam para o repositório principal; o link secundário aponta para a organização.
- Não criar avaliações, depoimentos ou métricas fictícias.

## Style Decisions

- O wordmark será sempre exibido como “Syntroph”, exatamente com a capitalização da marca; o símbolo enviado será acompanhado por um único detalhe visual ciano de troca, sem pontuação decorativa no nome.
- Os cards de adaptadores devem funcionar como um ecossistema: cada card expõe o port/organismo, um nó luminoso e uma linha de conexão, alternando ciano para fluxo/memória e violeta para adaptação/recepção.
- O vocabulário de linhas finas, nós e anotações metabólicas acompanha também as seções posteriores, para que a página inteira pareça um único sistema vivo.

## Style Decisions — evolução da documentação

A documentação mantém pelo menos um sinal bio-futurista por seção, com nós, conectores, bordas de gradiente e anotações de sistema. Os cards e links continuam expondo port/organismo e pertencimento ao event bus, e o wordmark usa sempre o ponto ciano de troca ao lado do nome exato Syntroph.
