# Evolução Syntroph

- [x] Adicionar uma seção interativa Runtime → Memory → Graph na home.
- [x] Criar estados de seleção, progresso e conteúdo contextual para o fluxo de dados.
- [x] Melhorar hover/foco dos cards de adaptadores com conectores e feedback visual.
- [x] Suavizar a transição do seletor dark/light e manter acessibilidade.
- [x] Criar a rota `/docs` com documentação detalhada e exemplos práticos.
- [x] Integrar links oficiais para organização, repositório, issues e documentação do GitHub.
- [x] Validar tipos, build, navegação e responsividade.
- [x] Adicionar changelog com notas e links para releases oficiais do GitHub.
- [x] Adicionar parâmetros personalizados ao playground Runtime/Memory/Graph.
- [x] Adicionar busca funcional para configurações YAML e exemplos de código.
- [x] Validar estados, filtros, links oficiais e build final.
